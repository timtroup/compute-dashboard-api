package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.exceptions.InvalidRegionParameterException;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.regions.Region;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class StringToRegionConverterTest {

    @Test
    void convert() {
        StringToRegionConverter testee = new StringToRegionConverter();
        Region region = testee.convert("eu-west-1");
        assertThat(region).isEqualTo(Region.EU_WEST_1);
    }

    @Test
    void convertThrowsInvalidRegionParameterExceptionnWhenInvalidRegionParameter() {
        StringToRegionConverter testee = new StringToRegionConverter();
        assertThrows(InvalidRegionParameterException.class, () -> {
            testee.convert("invalid");
        });
    }
}