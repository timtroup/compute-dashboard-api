package com.somerledsolutions.computedashboard.api;

import com.somerledsolutions.computedashboard.exceptions.PageIndexOutOfBoundsException;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import com.somerledsolutions.computedashboard.service.EC2MetadataService;
import com.somerledsolutions.computedashboard.util.PageSortProcessor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import software.amazon.awssdk.regions.Region;

import java.util.ArrayList;

import static org.hamcrest.Matchers.*;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ComputeDashboardController.class)
class ComputeDashboardControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EC2MetadataService ec2MetadataService;

    @MockBean
    private PageSortProcessor pageSortProcessor;

    private static final String INSTANCE_NAME = "instanceName";
    private static final String INSTANCE_ID = "instanceId";
    private static final String RUNNING = "running";
    private static final String T2_MICRO = "t2.micro";
    private static final String EU_WEST_1B = "eu-west-1b";
    private static final String PUBLIC_IP_ADDRESS = "52.48.67.168";
    private static final String PRIVATE_IP_ADDRESS = "10.0.1.187";

    @Test
    void findByRegionReturnsEmptyArrayWhenNoInstances() throws Exception {

        given(ec2MetadataService.getInstanceMetaData(Region.EU_WEST_1)).willReturn(new ArrayList<>());

        this.mockMvc.perform(get("/api/ec2metadata/eu-west-1"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(0)));

    }

    @Test
    void findByRegionReturnsArrayWhenInstancesFound() throws Exception {

        ArrayList<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        EC2InstanceMetadata ec2InstanceMetadata = EC2InstanceMetadata.Builder.builder()
                .withName(INSTANCE_NAME)
                .withAvailabilityZone(EU_WEST_1B)
                .withInstanceId(INSTANCE_ID)
                .withInstanceType(T2_MICRO)
                .withPrivateIpAddress(PRIVATE_IP_ADDRESS)
                .withPublicIpAddress(PUBLIC_IP_ADDRESS)
                .withState(RUNNING)
                .build();
        ec2InstanceMetadataList.add(ec2InstanceMetadata);

        given(ec2MetadataService.getInstanceMetaData(Region.EU_WEST_1)).willReturn(ec2InstanceMetadataList);
        given(pageSortProcessor.process(ec2InstanceMetadataList, null, null, null)).willReturn(ec2InstanceMetadataList);


        this.mockMvc.perform(get("/api/ec2metadata/eu-west-1"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$.[0].name", is(INSTANCE_NAME)))
                .andExpect(jsonPath("$.[0].instanceId", is(INSTANCE_ID)))
                .andExpect(jsonPath("$.[0].instanceType", is(T2_MICRO)))
                .andExpect(jsonPath("$.[0].state", is(RUNNING)))
                .andExpect(jsonPath("$.[0].availabilityZone", is(EU_WEST_1B)))
                .andExpect(jsonPath("$.[0].publicIpAddress", is(PUBLIC_IP_ADDRESS)))
                .andExpect(jsonPath("$.[0].privateIpAddress", is(PRIVATE_IP_ADDRESS)));

    }

    @Test
    void findByRegionReturnsErrorWhenServiceFails() throws Exception {

        RuntimeException runtimeException = new RuntimeException("Some runtime error message");
        given(ec2MetadataService.getInstanceMetaData(Region.EU_WEST_1)).willThrow(runtimeException);

        this.mockMvc.perform(get("/api/ec2metadata/eu-west-1"))
                .andDo(print())
                .andExpect(status().is5xxServerError())
                .andExpect(jsonPath("$.status", is("INTERNAL_SERVER_ERROR")))
                .andExpect(jsonPath("$.message", is("Some runtime error message")))
                .andExpect(jsonPath("$.errors", hasSize(1)));

    }

    @Test
    void findByRegionReturnsErrorWhenInvalidRegion() throws Exception {

        this.mockMvc.perform(get("/api/ec2metadata/invalid"))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is("BAD_REQUEST")))
                .andExpect(jsonPath("$.message", containsString("Invalid region: invalid")))
                .andExpect(jsonPath("$.errors", hasSize(1)));
    }

    @Test
    void findByRegionReturnsErrorWhenInvalidSortByParameter() throws Exception {

        this.mockMvc.perform(get("/api/ec2metadata/eu-west-1?sortBy=invalid"))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is("BAD_REQUEST")))
                .andExpect(jsonPath("$.message", containsString("Invalid sort parameter: invalid")))
                .andExpect(jsonPath("$.errors", hasSize(1)));
    }

    @Test
    void findByRegionReturnsErrorWhenPageExceedsAvailableResults() throws Exception {

        ArrayList<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        EC2InstanceMetadata ec2InstanceMetadata = EC2InstanceMetadata.Builder.builder()
                .withName(INSTANCE_NAME)
                .withAvailabilityZone(EU_WEST_1B)
                .withInstanceId(INSTANCE_ID)
                .withInstanceType(T2_MICRO)
                .withPrivateIpAddress(PRIVATE_IP_ADDRESS)
                .withPublicIpAddress(PUBLIC_IP_ADDRESS)
                .withState(RUNNING)
                .build();
        ec2InstanceMetadataList.add(ec2InstanceMetadata);

        given(ec2MetadataService.getInstanceMetaData(Region.EU_WEST_1)).willReturn(ec2InstanceMetadataList);
        given(pageSortProcessor.process(ec2InstanceMetadataList, 10, null, null)).willThrow(new PageIndexOutOfBoundsException());

        this.mockMvc.perform(get("/api/ec2metadata/eu-west-1?page=10"))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is("BAD_REQUEST")))
                .andExpect(jsonPath("$.message", containsString("The requested page range is larger than the number of results available")))
                .andExpect(jsonPath("$.errors", hasSize(1)));
    }
}