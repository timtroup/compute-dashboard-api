package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class EC2MetadataSortUtilTest {

    private EC2MetadataSortUtil testee;

    @BeforeEach
    void setUp() {
        testee = new EC2MetadataSortUtil();
    }

    @Test
    void sortByName() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withName("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withName("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withName("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withName("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.NAME);
        assertThat(ec2InstanceMetadataList.get(0).name()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).name()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).name()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).name()).isEqualTo("Z");
    }

    @Test
    void sortByInstanceId() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceId("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceId("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceId("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceId("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.INSTANCE_ID);
        assertThat(ec2InstanceMetadataList.get(0).instanceId()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).instanceId()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).instanceId()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).instanceId()).isEqualTo("Z");
    }

    @Test
    void sortByInstanceType() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceType("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceType("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceType("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withInstanceType("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.INSTANCE_TYPE);
        assertThat(ec2InstanceMetadataList.get(0).instanceType()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).instanceType()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).instanceType()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).instanceType()).isEqualTo("Z");
    }

    @Test
    void sortByState() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withState("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withState("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withState("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withState("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.STATE);
        assertThat(ec2InstanceMetadataList.get(0).state()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).state()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).state()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).state()).isEqualTo("Z");
    }

    @Test
    void sortByAvailabilityZone() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withAvailabilityZone("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withAvailabilityZone("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withAvailabilityZone("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withAvailabilityZone("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.AVAILABILITY_ZONE);
        assertThat(ec2InstanceMetadataList.get(0).availabilityZone()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).availabilityZone()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).availabilityZone()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).availabilityZone()).isEqualTo("Z");
    }

    @Test
    void sortByPublicIpAddress() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPublicIpAddress("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPublicIpAddress("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPublicIpAddress("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPublicIpAddress("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.PUBLIC_IP_ADDRESS);
        assertThat(ec2InstanceMetadataList.get(0).publicIpAddress()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).publicIpAddress()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).publicIpAddress()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).publicIpAddress()).isEqualTo("Z");
    }

    @Test
    void sortByPrivateIpAddress() {
        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPrivateIpAddress("B").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPrivateIpAddress("W").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPrivateIpAddress("A").build());
        ec2InstanceMetadataList.add(EC2InstanceMetadata.Builder.builder().withPrivateIpAddress("Z").build());
        testee.sort(ec2InstanceMetadataList, SortByEnum.PRIVATE_IP_ADDRESS);
        assertThat(ec2InstanceMetadataList.get(0).privateIpAddress()).isEqualTo("A");
        assertThat(ec2InstanceMetadataList.get(1).privateIpAddress()).isEqualTo("B");
        assertThat(ec2InstanceMetadataList.get(2).privateIpAddress()).isEqualTo("W");
        assertThat(ec2InstanceMetadataList.get(3).privateIpAddress()).isEqualTo("Z");
    }
}