package com.somerledsolutions.computedashboard.service;

import com.somerledsolutions.computedashboard.mapper.EC2InstanceMetadataMapper;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.Ec2ClientBuilder;
import software.amazon.awssdk.services.ec2.model.*;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class EC2MetadataServiceTest {

    @Mock
    private Ec2ClientBuilder ec2ClientBuilder;
    private DescribeInstancesRequest.Builder describeInstancesRequestBuilder;

    @Mock
    private EC2InstanceMetadataMapper mapper;

    private EC2MetadataService testee;


    @BeforeEach
    void setUp() {
        when(ec2ClientBuilder.region(any(Region.class))).thenReturn(ec2ClientBuilder);
        when(ec2ClientBuilder.endpointOverride(any(URI.class))).thenReturn(ec2ClientBuilder);
        describeInstancesRequestBuilder = mock(DescribeInstancesRequest.Builder.class, RETURNS_SELF);
    }

    @Test
    void getInstanceMetaDataShouldReturnEmptyListWhenNoInstancesFound() {
        testee = new EC2MetadataService(ec2ClientBuilder, describeInstancesRequestBuilder, mapper, null, 6);
        stubAWSEC2ClientToReturn(0);

        List<EC2InstanceMetadata> actual = testee.getInstanceMetaData(Region.EU_WEST_1);
        assertThat(actual).size().isEqualTo(0);
        verify(mapper, never()).getEc2InstanceMetadataFrom(any(Instance.class));
        verify(ec2ClientBuilder, times(1)).region(Region.EU_WEST_1);
        verify(ec2ClientBuilder, times(1)).build();
    }

    @Test
    void getInstanceMetaDataShouldReturnOneItemWhenOneItemFound() {
        testee = new EC2MetadataService(ec2ClientBuilder, describeInstancesRequestBuilder, mapper, null, 6);
        stubAWSEC2ClientToReturn(1);

        List<EC2InstanceMetadata> actual = testee.getInstanceMetaData(Region.EU_WEST_1);
        assertThat(actual).size().isEqualTo(1);
        verify(mapper, times(1)).getEc2InstanceMetadataFrom(any(Instance.class));
        verify(ec2ClientBuilder, times(1)).region(Region.EU_WEST_1);
        verify(ec2ClientBuilder, times(1)).build();
    }

    @Test
    void getInstanceMetaDataShouldOverrideAWSEndpointURLWhenAwsClientEndpointOverrideIsProvided() {
        testee = new EC2MetadataService(ec2ClientBuilder, describeInstancesRequestBuilder, mapper, "http://localhost:51867", 6);

        stubAWSEC2ClientToReturn(1);

        List<EC2InstanceMetadata> actual = testee.getInstanceMetaData(Region.EU_WEST_1);
        assertThat(actual).size().isEqualTo(1);
        verify(mapper, times(1)).getEc2InstanceMetadataFrom(any(Instance.class));
        verify(ec2ClientBuilder, times(1)).region(Region.EU_WEST_1);

        ArgumentCaptor<URI> uriArgumentCaptor = ArgumentCaptor.forClass(URI.class);
        verify(ec2ClientBuilder, times(1)).endpointOverride(uriArgumentCaptor.capture());

        assertThat(uriArgumentCaptor.getValue().toString()).isEqualTo("http://localhost:51867");
        verify(ec2ClientBuilder, times(1)).build();
    }

    @Test
    void getInstanceMetaDataShouldThrowExceptionWhenEC2ClientFails() {
        testee = new EC2MetadataService(ec2ClientBuilder, describeInstancesRequestBuilder, mapper, null, 6);
        stubAWSEC2ClientToThrowException();

        Exception exception = assertThrows(RuntimeException.class, () -> {
            testee.getInstanceMetaData(Region.EU_WEST_1);
        });

        verify(mapper, never()).getEc2InstanceMetadataFrom(any(Instance.class));
        verify(ec2ClientBuilder, times(1)).region(Region.EU_WEST_1);
        verify(ec2ClientBuilder, times(1)).build();
    }

    private void stubAWSEC2ClientToThrowException() {
        Ec2Client ec2Client = mock(Ec2Client.class);
        when(ec2ClientBuilder.build()).thenReturn(ec2Client);

        DescribeInstancesRequest describeInstancesRequest = mock(DescribeInstancesRequest.class);
        when(describeInstancesRequestBuilder.build()).thenReturn(describeInstancesRequest);

        when(ec2Client.describeInstances(any(DescribeInstancesRequest.class))).thenThrow(Ec2Exception.class);
    }

    private List<Instance> getInstances(int numberOfInstances) {
        List<Instance> expected = new ArrayList<>();
        for (int i = 0; i < numberOfInstances; i++) {
            Instance instance = Instance.builder().build();
            expected.add(instance);
        }
        return expected;
    }

    private void stubAWSEC2ClientToReturn(int numberOfInstances) {
        Ec2Client ec2Client = mock(Ec2Client.class);
        when(ec2ClientBuilder.build()).thenReturn(ec2Client);

        DescribeInstancesRequest describeInstancesRequest = mock(DescribeInstancesRequest.class);
        when(describeInstancesRequestBuilder.build()).thenReturn(describeInstancesRequest);

        DescribeInstancesResponse mockDescribeInstancesResponse = mock(DescribeInstancesResponse.class);
        when(ec2Client.describeInstances(any(DescribeInstancesRequest.class))).thenReturn(mockDescribeInstancesResponse);

        Reservation reservation = mock(Reservation.class);
        when(reservation.instances()).thenReturn(getInstances(numberOfInstances));

        List<Reservation> reservations = new ArrayList<>();
        reservations.add(reservation);

        when(mockDescribeInstancesResponse.reservations()).thenReturn(reservations);
    }
}