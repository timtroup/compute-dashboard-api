package com.somerledsolutions.computedashboard.mapper;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.services.ec2.model.Instance;
import software.amazon.awssdk.services.ec2.model.InstanceState;
import software.amazon.awssdk.services.ec2.model.Placement;
import software.amazon.awssdk.services.ec2.model.Tag;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

class EC2InstanceMetadataMapperTest {

    private static final String INSTANCE_NAME = "instanceName";
    private static final String INSTANCE_ID = "instanceId";
    private static final String RUNNING = "running";
    private static final String T2_MICRO = "t2.micro";
    private static final String EU_WEST_1B = "eu-west-1b";
    private static final String PUBLIC_IP_ADDRESS = "52.48.67.168";
    private static final String PRIVATE_IP_ADDRESS = "10.0.1.187";

    private EC2InstanceMetadataMapper testee;

    @BeforeEach
    void setup() {
        Mapper mapper = DozerBeanMapperBuilder.create().withMappingFiles("dozer-mapping.xml").build();
        testee = new EC2InstanceMetadataMapper(mapper);
    }

    @Test
    void getEc2InstanceMetadataFromMapsInstanceData() {
        ArrayList<Tag> tags = new ArrayList<>();
        Tag tag = Tag.builder().key("Name").value(INSTANCE_NAME).build();
        tags.add(tag);

        Instance instance = Instance.builder()
                .instanceId(INSTANCE_ID)
                .state(InstanceState.builder().name(RUNNING).build())
                .instanceType(T2_MICRO)
                .publicIpAddress(PUBLIC_IP_ADDRESS)
                .privateIpAddress(PRIVATE_IP_ADDRESS)
                .placement(Placement.builder().availabilityZone(EU_WEST_1B).build())
                .tags(tags)
                .build();

        EC2InstanceMetadata ec2InstanceMetadata = testee.getEc2InstanceMetadataFrom(instance);
        assertThat(ec2InstanceMetadata.name()).isEqualTo(INSTANCE_NAME);
        assertThat(ec2InstanceMetadata.instanceId()).isEqualTo(INSTANCE_ID);
        assertThat(ec2InstanceMetadata.state()).isEqualTo(RUNNING);
        assertThat(ec2InstanceMetadata.instanceType()).isEqualTo(T2_MICRO);
        assertThat(ec2InstanceMetadata.availabilityZone()).isEqualTo(EU_WEST_1B);
        assertThat(ec2InstanceMetadata.publicIpAddress()).isEqualTo(PUBLIC_IP_ADDRESS);
        assertThat(ec2InstanceMetadata.privateIpAddress()).isEqualTo(PRIVATE_IP_ADDRESS);
    }

    @Test
    void getEc2InstanceMetadataFromMapsInstanceDataWhenHasNoValues() {
        Instance instance = Instance.builder().build();

        EC2InstanceMetadata ec2InstanceMetadata = testee.getEc2InstanceMetadataFrom(instance);
        assertThat(ec2InstanceMetadata.name()).isNullOrEmpty();
        assertThat(ec2InstanceMetadata.instanceId()).isNullOrEmpty();
        assertThat(ec2InstanceMetadata.state()).isNullOrEmpty();
        assertThat(ec2InstanceMetadata.instanceType()).isNullOrEmpty();
        assertThat(ec2InstanceMetadata.availabilityZone()).isNullOrEmpty();
        assertThat(ec2InstanceMetadata.publicIpAddress()).isNullOrEmpty();
        assertThat(ec2InstanceMetadata.privateIpAddress()).isNullOrEmpty();
    }
}