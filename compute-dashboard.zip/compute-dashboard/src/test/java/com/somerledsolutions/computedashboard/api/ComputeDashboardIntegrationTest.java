package com.somerledsolutions.computedashboard.api;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Disabled
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ContextConfiguration(initializers = {WireMockInitializer.class})
public class ComputeDashboardIntegrationTest {

    @Autowired
    private WireMockServer wireMockServer;

    @Autowired
    private WebTestClient webTestClient;

    @LocalServerPort
    private Integer port;

    @BeforeAll
    public static void beforeAll() {
        System.setProperty("aws.accessKeyId", "ACCESS_KEY_ID");
        System.setProperty("aws.secretAccessKey", "SECRET_ACCESS_KEY");
    }

    @AfterEach
    public void afterEach() {
        this.wireMockServer.resetAll();
    }


//0 items
//0 items sorted
//0 items page=0
//0 items page=0 pageSize=15
//0 items page=1
//
//1 item
//1 item sorted
//1 item page=0
//1 item page=0  pageSize=15
// 1 item page=1
//
//25 items
//25 items sorted
//25 items page=0
//25 items page=3
//25 items page=0 page size 7
//25 items page=1 page size 7
//25 items page size 7 page=4
//
//Call with non-existent region



    @Test
    public void testGetShouldReturnEmptyArrayWhenNoIstancesFound() {
        WireMock.configureFor("localhost", wireMockServer.port());
        this.wireMockServer.stubFor(
                WireMock.post("/")
                        .willReturn(aResponse()
                                .withHeader("Content-Type", MediaType.APPLICATION_XML_VALUE)
                                .withBodyFile("DescribeInstancesResponse.xml"))
        );

        this.wireMockServer.stubFor(
                WireMock.get("/?Action=DescribeInstances")
                        .willReturn(aResponse()
                                .withHeader("Content-Type", MediaType.APPLICATION_XML_VALUE)
                                .withBodyFile("DescribeInstancesResponse.xml"))
        );

        this.webTestClient
                .get()
                .uri("http://localhost:" + port + "/api/ec2metadata/eu-west-1")
                .exchange()
                .expectStatus()
                .is2xxSuccessful()
                .expectHeader()
                .contentType(APPLICATION_JSON_VALUE)
                .expectBody()
                .jsonPath("$").isArray()
                .jsonPath("$").isEmpty();
    }

//    @Test
//    public void testGetAllTodosShouldPropagateErrorMessageFromClient() {
//        this.wireMockServer.stubFor(
//                WireMock.get("/")
//                        .willReturn(aResponse()
//                                .withStatus(403))
//        );
//
//        this.webTestClient
//                .get()
//                .uri("http://localhost:" + port + "/api/ec2metadata/eu-west-1")
//                .exchange()
//                .expectStatus()
//                .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR_500);
//    }
}