package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.exceptions.InvalidSortParameterException;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class StringToEnumConverterTest {

    @Test
    void convert() {
        StringToEnumConverter testee = new StringToEnumConverter();
        SortByEnum name = testee.convert("name");
        assertThat(name).isEqualTo(SortByEnum.NAME);
    }

    @Test
    void convertThrowsInvalidSortParameterExceptionWhenInvalidSortByParameter() {
        StringToEnumConverter testee = new StringToEnumConverter();
        assertThrows(InvalidSortParameterException.class, () -> {
            testee.convert("invalid");
        });
    }
}