package com.somerledsolutions.computedashboard.config;

import com.somerledsolutions.computedashboard.util.StringToEnumConverter;
import com.somerledsolutions.computedashboard.util.StringToRegionConverter;
import org.junit.jupiter.api.Test;
import org.springframework.format.FormatterRegistry;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class WebConfigTest {

    @Test
    void addFormatters() {
        WebConfig testee = new WebConfig();
        FormatterRegistry formatterRegistry = mock(FormatterRegistry.class);
        testee.addFormatters(formatterRegistry);
        verify(formatterRegistry, times(1)).addConverter(any(StringToEnumConverter.class));
        verify(formatterRegistry, times(1)).addConverter(any(StringToRegionConverter.class));
    }
}