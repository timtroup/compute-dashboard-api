package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.exceptions.PageIndexOutOfBoundsException;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
class PageSortProcessorTest {

    @Mock
    private EC2MetadataSortUtil ec2MetadataSortUtil;

    private PageSortProcessor testee;

    @BeforeEach
    void setUp() {
        testee = new PageSortProcessor(ec2MetadataSortUtil, 10);
    }

    @Test
    void processListWith10InstancesWithPage0AndPageSize10() {
        List<EC2InstanceMetadata> list = getInstances(10);
        int page = 0;
        int pageSize = 10;

        List<EC2InstanceMetadata> processed = testee.process(list, page, pageSize, SortByEnum.NAME);
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
        assertThat(processed.size()).isEqualTo(10);
    }

    @Test
    void processListWith10InstancesWithPage0AndPageSize5() {
        List<EC2InstanceMetadata> list = getInstances(10);
        int page = 0;
        int pageSize = 5;

        List<EC2InstanceMetadata> processed = testee.process(list, page, pageSize, SortByEnum.NAME);
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
        assertThat(processed.size()).isEqualTo(5);
        assertThat(processed).isEqualTo(list.subList(0, 5));
    }

    @Test
    void processListWith10InstancesWithPage1AndPageSize5() {
        List<EC2InstanceMetadata> list = getInstances(10);
        int page = 1;
        int pageSize = 5;

        List<EC2InstanceMetadata> processed = testee.process(list, page, pageSize, SortByEnum.NAME);
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
        assertThat(processed.size()).isEqualTo(5);
        assertThat(processed).isEqualTo(list.subList(5, 10));
    }

    @Test
    void processListWithPageSizeGreaterThanAvailableResults() {
        List<EC2InstanceMetadata> list = getInstances(5);
        int page = 0;
        int pageSize = 10;

        List<EC2InstanceMetadata> processed = testee.process(list, page, pageSize, SortByEnum.NAME);
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
        assertThat(processed.size()).isEqualTo(5);
        assertThat(processed).isEqualTo(list);
    }

    @Test
    void processListUsesDefaultPageSizeWhenNoneSpecified() {
        List<EC2InstanceMetadata> list = getInstances(20);
        int page = 1;

        List<EC2InstanceMetadata> processed = testee.process(list, page, null, SortByEnum.NAME);
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
        assertThat(processed.size()).isEqualTo(10);
        assertThat(processed).isEqualTo(list.subList(10, 20));
    }

    @Test
    void processListReturnsAllResultsWhenNoPageSpecified() {
        List<EC2InstanceMetadata> list = getInstances(20);

        List<EC2InstanceMetadata> processed = testee.process(list, null, null, SortByEnum.NAME);
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
        assertThat(processed.size()).isEqualTo(20);
        assertThat(processed).isEqualTo(list);
    }

    @Test
    void processListWithPageGreaterThanAvailableResults() {
        List<EC2InstanceMetadata> list = getInstances(5);
        int page = 1;
        int pageSize = 10;

        Exception exception = assertThrows(PageIndexOutOfBoundsException.class, () -> {
            testee.process(list, page, pageSize, SortByEnum.NAME);
        });

        assertThat(exception.getMessage()).isEqualTo("The requested page range is larger than the number of results available");
        verify(ec2MetadataSortUtil, times(1)).sort(list, SortByEnum.NAME);
    }

    private List<EC2InstanceMetadata> getInstances(int numberOfInstances) {
        List<EC2InstanceMetadata> expected = new ArrayList<>();
        for (int i = 0; i < numberOfInstances; i++) {
            expected.add(EC2InstanceMetadata.Builder.builder().build());
        }
        return expected;
    }
}