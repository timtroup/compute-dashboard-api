package com.somerledsolutions.computedashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.Ec2ClientBuilder;
import software.amazon.awssdk.services.ec2.model.DescribeInstancesRequest;

@SpringBootApplication
public class ComputeDashboardApplication {

    public static void main(String[] args) {
        SpringApplication.run(ComputeDashboardApplication.class, args);
    }

    @Bean
    public Ec2ClientBuilder getEc2ClientBuilder() {
        return Ec2Client.builder();
    }

    @Bean
    public DescribeInstancesRequest.Builder getDescribeInstancesRequestBuilder() {
        return DescribeInstancesRequest.builder();
    }

}
