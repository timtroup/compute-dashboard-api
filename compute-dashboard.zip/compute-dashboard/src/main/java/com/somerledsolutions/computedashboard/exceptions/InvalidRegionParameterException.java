package com.somerledsolutions.computedashboard.exceptions;

public class InvalidRegionParameterException extends RuntimeException {

    public InvalidRegionParameterException(String message) {
        super(message);
    }
}
