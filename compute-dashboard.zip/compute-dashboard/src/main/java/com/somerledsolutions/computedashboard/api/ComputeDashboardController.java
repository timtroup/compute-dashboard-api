package com.somerledsolutions.computedashboard.api;

import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import com.somerledsolutions.computedashboard.service.EC2MetadataService;
import com.somerledsolutions.computedashboard.util.PageSortProcessor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import software.amazon.awssdk.regions.Region;

import java.util.List;

@RestController
@RequestMapping("/api/ec2metadata")

public class ComputeDashboardController {

    private final EC2MetadataService ec2MetadataService;
    private final PageSortProcessor pageSortProcessor;

    public ComputeDashboardController(EC2MetadataService ec2MetadataService, PageSortProcessor pageSortProcessor) {
        this.ec2MetadataService = ec2MetadataService;
        this.pageSortProcessor = pageSortProcessor;
    }

    @GetMapping(path = "/{region}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<EC2InstanceMetadata> findByRegion(@PathVariable Region region, @RequestParam(required = false) Integer page, @RequestParam(required = false) Integer pageSize, @RequestParam(name = "sortBy", required = false) SortByEnum sortBy) {
        List<EC2InstanceMetadata> instanceMetaData = ec2MetadataService.getInstanceMetaData(region);
        return pageSortProcessor.process(instanceMetaData, page, pageSize, sortBy);
    }
}