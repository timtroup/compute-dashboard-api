package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.exceptions.PageIndexOutOfBoundsException;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PageSortProcessor {

    private EC2MetadataSortUtil ec2MetadataSortUtil;
    private Integer defaultPageSize;

    public PageSortProcessor(EC2MetadataSortUtil ec2MetadataSortUtil, @Value("${default.page.size}") Integer defaultPageSize) {
        this.ec2MetadataSortUtil = ec2MetadataSortUtil;
        this.defaultPageSize = defaultPageSize;
    }

    public List<EC2InstanceMetadata> process(List<EC2InstanceMetadata> list, Integer page, Integer pageSize, SortByEnum sortBy) {

        if (sortBy != null) {
            ec2MetadataSortUtil.sort(list, sortBy);
        }

        if (page != null) {
            pageSize = getPageSize(pageSize);
            int fromIndex = page * pageSize;
            checkListSize(list, fromIndex);
            int endIndex = getEndIndex(list, page, pageSize);
            return list.subList(fromIndex, endIndex);
        } else {
            return list;
        }
    }

    private int getPageSize(Integer pageSize) {
        return pageSize != null ? pageSize : defaultPageSize;
    }

    private int getEndIndex(List<EC2InstanceMetadata> list, Integer page, Integer pageSize) {
        int endIndex = (page * pageSize) + pageSize;
        if (endIndex > list.size()) {
            return list.size();
        } else {
            return endIndex;
        }
    }

    private void checkListSize(List<EC2InstanceMetadata> list, int fromIndex) {
        if (list.size() < fromIndex) {
            throw new PageIndexOutOfBoundsException();
        }
    }
}
