package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.exceptions.InvalidSortParameterException;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.List;

@Component
public class EC2MetadataSortUtil {

    public List<EC2InstanceMetadata> sort(List<EC2InstanceMetadata> ec2InstanceMetadata, SortByEnum sortBy) {
        try {
            Method method = EC2InstanceMetadata.class.getMethod(sortBy.sortBy());
            Comparator<EC2InstanceMetadata> compareByName = (EC2InstanceMetadata o1, EC2InstanceMetadata o2) -> {
                try {
                    return ((String) method.invoke(o1)).compareTo((String) method.invoke(o2));
                } catch (IllegalAccessException | InvocationTargetException e) {
                    throw new InvalidSortParameterException(e.getMessage());
                }
            };
            ec2InstanceMetadata.sort(compareByName);
        } catch (NoSuchMethodException e) {
            throw new InvalidSortParameterException(e.getMessage());
        }

        return ec2InstanceMetadata;
    }

}
