package com.somerledsolutions.computedashboard.util;


import com.somerledsolutions.computedashboard.exceptions.InvalidRegionParameterException;
import org.springframework.core.convert.converter.Converter;
import software.amazon.awssdk.regions.Region;

public class StringToRegionConverter implements Converter<String, Region> {

    @Override
    public Region convert(String from) {
        Region region = Region.of(from);
        if (Region.regions().contains(region)) {
            return region;
        } else {
            throw new InvalidRegionParameterException("Invalid region: " + from);
        }
    }
}
