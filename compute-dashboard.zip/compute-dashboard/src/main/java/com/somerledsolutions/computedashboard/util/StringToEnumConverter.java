package com.somerledsolutions.computedashboard.util;

import com.somerledsolutions.computedashboard.exceptions.InvalidSortParameterException;
import com.somerledsolutions.computedashboard.model.SortByEnum;
import org.springframework.core.convert.converter.Converter;

public class StringToEnumConverter implements Converter<String, SortByEnum> {

    @Override
    public SortByEnum convert(String from) {
        try {
            return SortByEnum.valueOf(from.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new InvalidSortParameterException("Invalid sort parameter: " + from);
        }
    }
}
