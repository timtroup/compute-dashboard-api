package com.somerledsolutions.computedashboard.mapper;

import com.github.dozermapper.core.Mapper;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.ec2.model.Instance;
import software.amazon.awssdk.services.ec2.model.Tag;

@Component
public class EC2InstanceMetadataMapper {

    private Mapper mapper;

    public EC2InstanceMetadataMapper(Mapper mapper) {
        this.mapper = mapper;
    }

    public EC2InstanceMetadata getEc2InstanceMetadataFrom(Instance instance) {
        EC2InstanceMetadata ec2InstanceMetadata = EC2InstanceMetadata.Builder.builder().build();
        mapper.map(instance, ec2InstanceMetadata);
        setInstanceNameMetadata(instance, ec2InstanceMetadata);
        return ec2InstanceMetadata;
    }

    private void setInstanceNameMetadata(Instance instance, EC2InstanceMetadata ec2InstanceMetadata) {
        for (Tag tag : instance.tags()) {
            if ("Name".equals(tag.key())) {
                ec2InstanceMetadata.setName(tag.value());
            }
        }
    }
}
