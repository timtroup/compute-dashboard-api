package com.somerledsolutions.computedashboard.exceptions;

public class PageIndexOutOfBoundsException extends RuntimeException {

    public PageIndexOutOfBoundsException() {
        super("The requested page range is larger than the number of results available");
    }
}
