package com.somerledsolutions.computedashboard.config;

import com.somerledsolutions.computedashboard.util.StringToEnumConverter;
import com.somerledsolutions.computedashboard.util.StringToRegionConverter;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new StringToEnumConverter());
        registry.addConverter(new StringToRegionConverter());
    }
}
