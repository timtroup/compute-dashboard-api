package com.somerledsolutions.computedashboard.service;

import com.somerledsolutions.computedashboard.exceptions.EC2ClientException;
import com.somerledsolutions.computedashboard.mapper.EC2InstanceMetadataMapper;
import com.somerledsolutions.computedashboard.model.EC2InstanceMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.Ec2ClientBuilder;
import software.amazon.awssdk.services.ec2.model.*;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * Describes all EC2 instances running in a given region associated with an AWS account
 */
@Service
public class EC2MetadataService {

    private String awsClientEndpointOverride;
    private Ec2ClientBuilder ec2ClientBuilder;
    private DescribeInstancesRequest.Builder describeInstancesRequestBuilder;
    private EC2InstanceMetadataMapper mapper;
    private Integer maxResults;

    private static final Logger LOGGER = LoggerFactory.getLogger(EC2MetadataService.class);

    public EC2MetadataService(Ec2ClientBuilder ec2ClientBuilder,
                              DescribeInstancesRequest.Builder describeInstancesRequestBuilder,
                              EC2InstanceMetadataMapper mapper,
                              @Value("${aws.client.endpoint.override}") final String awsClientEndpointOverride,
                              @Value("${aws.client.max.results}") final Integer maxResults) {
        this.ec2ClientBuilder = ec2ClientBuilder;
        this.describeInstancesRequestBuilder = describeInstancesRequestBuilder;
        this.mapper = mapper;
        this.awsClientEndpointOverride = awsClientEndpointOverride;
        this.maxResults = maxResults;
    }

    public List<EC2InstanceMetadata> getInstanceMetaData(Region region) {

        LOGGER.info("Retrieving EC2 instance metadata.");

        List<EC2InstanceMetadata> ec2InstanceMetadataList = new ArrayList<>();
        Ec2Client ec2 = getEc2Client(region);
        String nextToken = null;

        try {
            do {
                DescribeInstancesResponse response = getDescribeInstancesResponse(ec2, nextToken);
                for (Reservation reservation : response.reservations()) {
                    for (Instance instance : reservation.instances()) {
                        ec2InstanceMetadataList.add(mapper.getEc2InstanceMetadataFrom(instance));
                    }
                }
                nextToken = response.nextToken();
            } while (nextToken != null);

        } catch (Ec2Exception e) {
            LOGGER.error("Error retrieving EC2 instance metadata.", e);
            throw new EC2ClientException(e);
        }

        return ec2InstanceMetadataList;
    }

    private Ec2Client getEc2Client(Region region) {
        ec2ClientBuilder = ec2ClientBuilder.region(region);

        if (!StringUtils.isEmpty(awsClientEndpointOverride)) {
            ec2ClientBuilder = ec2ClientBuilder.endpointOverride(URI.create(awsClientEndpointOverride));
        }

        return ec2ClientBuilder.build();
    }

    private DescribeInstancesResponse getDescribeInstancesResponse(Ec2Client ec2, String nextToken) {
        DescribeInstancesRequest request = describeInstancesRequestBuilder.maxResults(maxResults).nextToken(nextToken).build();
        return ec2.describeInstances(request);
    }
}