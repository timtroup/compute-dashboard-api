package com.somerledsolutions.computedashboard.exceptions;

public class InvalidSortParameterException extends RuntimeException {

    public InvalidSortParameterException(String message) {
        super(message);
    }

}
