package com.somerledsolutions.computedashboard.model;

import com.fasterxml.jackson.annotation.JsonGetter;

public class EC2InstanceMetadata {

    private String name;
    private String instanceId;
    private String instanceType;
    private String state;
    private String availabilityZone;
    private String publicIpAddress;
    private String privateIpAddress;

    private EC2InstanceMetadata() {

    }

    @JsonGetter("name")
    public String name() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonGetter("instanceId")
    public String instanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    @JsonGetter("instanceType")
    public String instanceType() {
        return instanceType;
    }

    public void setInstanceType(String instanceType) {
        this.instanceType = instanceType;
    }

    @JsonGetter("state")
    public String state() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @JsonGetter("availabilityZone")
    public String availabilityZone() {
        return availabilityZone;
    }

    public void setAvailabilityZone(String availabilityZone) {
        this.availabilityZone = availabilityZone;
    }

    @JsonGetter("publicIpAddress")
    public String publicIpAddress() {
        return publicIpAddress;
    }

    public void setPublicIpAddress(String publicIpAddress) {
        this.publicIpAddress = publicIpAddress;
    }

    @JsonGetter("privateIpAddress")
    public String privateIpAddress() {
        return privateIpAddress;
    }

    public void setPrivateIpAddress(String privateIpAddress) {
        this.privateIpAddress = privateIpAddress;
    }

    public static final class Builder {
        private String name;
        private String instanceId;
        private String instanceType;
        private String state;
        private String availabilityZone;
        private String publicIpAddress;
        private String privateIpAddress;

        private Builder() {
        }

        public static Builder builder() {
            return new Builder();
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withInstanceId(String instanceId) {
            this.instanceId = instanceId;
            return this;
        }

        public Builder withInstanceType(String instanceType) {
            this.instanceType = instanceType;
            return this;
        }

        public Builder withState(String state) {
            this.state = state;
            return this;
        }

        public Builder withAvailabilityZone(String availabilityZone) {
            this.availabilityZone = availabilityZone;
            return this;
        }

        public Builder withPublicIpAddress(String publicIpAddress) {
            this.publicIpAddress = publicIpAddress;
            return this;
        }

        public Builder withPrivateIpAddress(String privateIpAddress) {
            this.privateIpAddress = privateIpAddress;
            return this;
        }

        public EC2InstanceMetadata build() {
            EC2InstanceMetadata eC2InstanceMetadata = new EC2InstanceMetadata();
            eC2InstanceMetadata.setName(name);
            eC2InstanceMetadata.setInstanceId(instanceId);
            eC2InstanceMetadata.setInstanceType(instanceType);
            eC2InstanceMetadata.setState(state);
            eC2InstanceMetadata.setAvailabilityZone(availabilityZone);
            eC2InstanceMetadata.setPublicIpAddress(publicIpAddress);
            eC2InstanceMetadata.setPrivateIpAddress(privateIpAddress);
            return eC2InstanceMetadata;
        }
    }
}
