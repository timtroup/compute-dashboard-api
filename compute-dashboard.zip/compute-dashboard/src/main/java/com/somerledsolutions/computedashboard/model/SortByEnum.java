package com.somerledsolutions.computedashboard.model;

public enum SortByEnum {

    NAME("name"),
    INSTANCE_ID("instanceId"),
    INSTANCE_TYPE("instanceType"),
    STATE("state"),
    AVAILABILITY_ZONE("availabilityZone"),
    PUBLIC_IP_ADDRESS("publicIpAddress"),
    PRIVATE_IP_ADDRESS("privateIpAddress");

    private final String sortBy;

    SortByEnum(String sortBy) {
        this.sortBy = sortBy;
    }

    public String sortBy() {
        return sortBy;
    }

}
