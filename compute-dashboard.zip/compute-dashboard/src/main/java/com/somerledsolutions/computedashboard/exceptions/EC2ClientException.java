package com.somerledsolutions.computedashboard.exceptions;

public class EC2ClientException extends RuntimeException {

    public EC2ClientException(Throwable t) {
        super(t);
    }

}
